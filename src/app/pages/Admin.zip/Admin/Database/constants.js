export const DATABASE_PANEL_HEADER = ['Users', 'Hospitals', 'Agents', 'Transactions']
